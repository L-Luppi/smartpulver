-- MySQL dump 10.13  Distrib 8.0.43, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: smartpulver
-- ------------------------------------------------------
-- Server version	8.0.43-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agrofit_acao`
--

DROP TABLE IF EXISTS `agrofit_acao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agrofit_acao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `descricao` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=543 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agrofit_acao_prod`
--

DROP TABLE IF EXISTS `agrofit_acao_prod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agrofit_acao_prod` (
  `id_acao` int NOT NULL,
  `numero_registro` int NOT NULL,
  PRIMARY KEY (`id_acao`,`numero_registro`),
  KEY `fk_acao_idx` (`id_acao`),
  KEY `fk_prd_acao_idx` (`numero_registro`),
  CONSTRAINT `fk_acao` FOREIGN KEY (`id_acao`) REFERENCES `agrofit_acao` (`id`),
  CONSTRAINT `fk_prd_acao` FOREIGN KEY (`numero_registro`) REFERENCES `agrofit_produto` (`numero_registro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agrofit_categ_prod`
--

DROP TABLE IF EXISTS `agrofit_categ_prod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agrofit_categ_prod` (
  `id_categoria` int NOT NULL,
  `numero_registro` int NOT NULL,
  PRIMARY KEY (`id_categoria`,`numero_registro`),
  KEY `fk_classe_idx` (`id_categoria`),
  KEY `fk_prod_classe_idx` (`numero_registro`),
  CONSTRAINT `fk_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `agrofit_categoria` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_prod_classe` FOREIGN KEY (`numero_registro`) REFERENCES `agrofit_produto` (`numero_registro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agrofit_categoria`
--

DROP TABLE IF EXISTS `agrofit_categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agrofit_categoria` (
  `id` int NOT NULL AUTO_INCREMENT,
  `descricao` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agrofit_classe_ambiental`
--

DROP TABLE IF EXISTS `agrofit_classe_ambiental`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agrofit_classe_ambiental` (
  `id` int NOT NULL AUTO_INCREMENT,
  `descricao` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agrofit_classe_toxicologica`
--

DROP TABLE IF EXISTS `agrofit_classe_toxicologica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agrofit_classe_toxicologica` (
  `id` int NOT NULL AUTO_INCREMENT,
  `descricao` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agrofit_cultura`
--

DROP TABLE IF EXISTS `agrofit_cultura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agrofit_cultura` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_nome` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=256 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agrofit_formulacao`
--

DROP TABLE IF EXISTS `agrofit_formulacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agrofit_formulacao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `formulacao` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `sigla` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agrofit_indicacao`
--

DROP TABLE IF EXISTS `agrofit_indicacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agrofit_indicacao` (
  `numero_registro` int NOT NULL,
  `id_praga` int NOT NULL,
  `id_cultura` int NOT NULL,
  PRIMARY KEY (`numero_registro`,`id_cultura`,`id_praga`) USING BTREE,
  KEY `fk_indic_prod_idx` (`numero_registro`),
  KEY `fk_praga_idx` (`id_praga`),
  KEY `fk_cultura_idx` (`id_cultura`),
  CONSTRAINT `fk_cultura` FOREIGN KEY (`id_cultura`) REFERENCES `agrofit_cultura` (`id`),
  CONSTRAINT `fk_indic_prod` FOREIGN KEY (`numero_registro`) REFERENCES `agrofit_produto` (`numero_registro`),
  CONSTRAINT `fk_praga` FOREIGN KEY (`id_praga`) REFERENCES `agrofit_praga` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agrofit_nomes_comerciais`
--

DROP TABLE IF EXISTS `agrofit_nomes_comerciais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agrofit_nomes_comerciais` (
  `id` int NOT NULL AUTO_INCREMENT,
  `numero_registro` int NOT NULL,
  `outro_nome` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_unique_name_produto` (`numero_registro`,`outro_nome`),
  CONSTRAINT `agrofit_nomes_comerciais_ibfk_1` FOREIGN KEY (`numero_registro`) REFERENCES `agrofit_produto` (`numero_registro`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1056 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agrofit_praga`
--

DROP TABLE IF EXISTS `agrofit_praga`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agrofit_praga` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome_cientifico` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_nome_cientifico` (`nome_cientifico`)
) ENGINE=InnoDB AUTO_INCREMENT=2063 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agrofit_praga_comum`
--

DROP TABLE IF EXISTS `agrofit_praga_comum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agrofit_praga_comum` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome_comum` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_praga_comum` (`nome_comum`)
) ENGINE=InnoDB AUTO_INCREMENT=2063 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agrofit_praga_names`
--

DROP TABLE IF EXISTS `agrofit_praga_names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agrofit_praga_names` (
  `id_praga` int NOT NULL,
  `id_praga_comum` int NOT NULL,
  PRIMARY KEY (`id_praga`,`id_praga_comum`),
  KEY `id_praga_comum` (`id_praga_comum`),
  CONSTRAINT `agrofit_praga_names_ibfk_1` FOREIGN KEY (`id_praga`) REFERENCES `agrofit_praga` (`id`),
  CONSTRAINT `agrofit_praga_names_ibfk_2` FOREIGN KEY (`id_praga_comum`) REFERENCES `agrofit_praga_comum` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agrofit_produto`
--

DROP TABLE IF EXISTS `agrofit_produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agrofit_produto` (
  `numero_registro` int NOT NULL,
  `marca_comercial` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `id_titular_registro` int NOT NULL,
  `id_formulacao` int DEFAULT NULL,
  `id_classe_toxicologica` int NOT NULL,
  `id_classe_ambiental` int NOT NULL,
  `produto_agricultura_organica` tinyint NOT NULL,
  `produto_biologico` tinyint NOT NULL,
  `inflamavel` tinyint NOT NULL,
  `corrosivo` tinyint NOT NULL,
  `url_bula` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `url_agrofit` varchar(255) DEFAULT NULL,
  `status_prod` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`numero_registro`),
  KEY `fk_formulacao_idx` (`id_formulacao`),
  KEY `fk_class_toxico_idx` (`id_classe_toxicologica`),
  KEY `fk_class_ambiental_idx` (`id_classe_ambiental`),
  KEY `fk_titular_reg` (`id_titular_registro`),
  CONSTRAINT `fk_class_ambiental` FOREIGN KEY (`id_classe_ambiental`) REFERENCES `agrofit_classe_ambiental` (`id`),
  CONSTRAINT `fk_class_toxico` FOREIGN KEY (`id_classe_toxicologica`) REFERENCES `agrofit_classe_toxicologica` (`id`),
  CONSTRAINT `fk_formulacao` FOREIGN KEY (`id_formulacao`) REFERENCES `agrofit_formulacao` (`id`),
  CONSTRAINT `fk_titular_reg` FOREIGN KEY (`id_titular_registro`) REFERENCES `agrofit_titular_reg` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agrofit_tec_aplic_prod`
--

DROP TABLE IF EXISTS `agrofit_tec_aplic_prod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agrofit_tec_aplic_prod` (
  `id` int NOT NULL,
  `numero_registro` int NOT NULL,
  PRIMARY KEY (`id`,`numero_registro`),
  KEY `fk_tecnica_prod_idx` (`numero_registro`),
  KEY `fk_produto_tecnica_idx` (`id`),
  CONSTRAINT `fk_produto` FOREIGN KEY (`numero_registro`) REFERENCES `agrofit_produto` (`numero_registro`),
  CONSTRAINT `fk_tecnica` FOREIGN KEY (`id`) REFERENCES `agrofit_tecnica_aplicacao` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agrofit_tecnica_aplicacao`
--

DROP TABLE IF EXISTS `agrofit_tecnica_aplicacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agrofit_tecnica_aplicacao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `descricao` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tecnica` (`descricao`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agrofit_titular_reg`
--

DROP TABLE IF EXISTS `agrofit_titular_reg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agrofit_titular_reg` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=515 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `area`
--

DROP TABLE IF EXISTS `area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `area` (
  `id` int NOT NULL,
  `id_produtor` int DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `nome_curto` varchar(50) DEFAULT NULL,
  `latitude` decimal(8,6) DEFAULT NULL,
  `longitude` decimal(9,6) DEFAULT NULL,
  `id_IBGE_cidade` int DEFAULT NULL,
  `cep` varchar(10) DEFAULT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `complemento` varchar(255) DEFAULT NULL,
  `bairro` varchar(100) DEFAULT NULL,
  `obs` varchar(255) DEFAULT NULL,
  `tenantID` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `area_idx` (`nome`),
  KEY `fk_produtor_idx` (`id_produtor`),
  KEY `fk_tenant_idx` (`tenantID`),
  CONSTRAINT `fk_produtor` FOREIGN KEY (`id_produtor`) REFERENCES `produtor` (`id`),
  CONSTRAINT `fk_tenant_area` FOREIGN KEY (`tenantID`) REFERENCES `assinante` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assinante`
--

DROP TABLE IF EXISTS `assinante`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assinante` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `validade_plano` bigint DEFAULT NULL,
  `fone` varchar(20) NOT NULL,
  `cpf_cnpj` varchar(25) DEFAULT NULL,
  `cep` varchar(10) DEFAULT NULL,
  `id_cidade_ibge` int DEFAULT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `numero` varchar(15) DEFAULT NULL,
  `bairro` varchar(100) DEFAULT NULL,
  `complemento` varchar(255) DEFAULT NULL,
  `status` enum('ativo','inativo','cancelado','suspenso','registrado') NOT NULL,
  `cognito_sub` varchar(45) DEFAULT NULL,
  `createdAt` bigint DEFAULT NULL,
  `updatedAt` bigint DEFAULT NULL,
  `stripe_customer_id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `fone_UNIQUE` (`fone`),
  UNIQUE KEY `cognito_sub_UNIQUE` (`cognito_sub`),
  UNIQUE KEY `cpf_cnpj_UNIQUE` (`cpf_cnpj`),
  KEY `idx_nome` (`nome`),
  KEY `fk_ibge_cidade_idx` (`id_cidade_ibge`),
  CONSTRAINT `fk_ibge_cidade` FOREIGN KEY (`id_cidade_ibge`) REFERENCES `ibge_cidades` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assinatura`
--

DROP TABLE IF EXISTS `assinatura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assinatura` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_plano` int DEFAULT NULL,
  `id_assinante` int DEFAULT NULL,
  `updatedAt` bigint DEFAULT NULL,
  `valor_pago` decimal(6,2) DEFAULT NULL,
  `renova_automatico` tinyint DEFAULT NULL,
  `createdAt` bigint DEFAULT NULL,
  `stripe_subscription_id` varchar(45) DEFAULT NULL,
  `stripe_price_id` varchar(45) DEFAULT NULL,
  `stripe_status` varchar(45) DEFAULT NULL,
  `current_period_end` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_plano_idx` (`id_plano`),
  KEY `fk_assinante_idx` (`id_assinante`),
  CONSTRAINT `fk_assinante` FOREIGN KEY (`id_assinante`) REFERENCES `assinante` (`id`),
  CONSTRAINT `fk_plano` FOREIGN KEY (`id_plano`) REFERENCES `plano` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drone`
--

DROP TABLE IF EXISTS `drone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drone` (
  `drone_id` int NOT NULL,
  `model_id` int NOT NULL,
  `tenantID` int DEFAULT NULL,
  `nome` varchar(45) NOT NULL,
  `ano_fabricacao` varchar(4) DEFAULT NULL,
  `ano_aquisicao` varchar(4) DEFAULT NULL,
  `ano_baixa` varchar(4) DEFAULT NULL,
  `data_ativacao` date DEFAULT NULL,
  `ns_fc` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Flight Control Serial Number',
  `ns_fc_board` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Flight Control Board SN',
  `registroANAC` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'Current ANAC Registration',
  `validade_registro_ANAC` date NOT NULL COMMENT 'ANAC expiry date',
  `serial` varchar(20) NOT NULL,
  `status` enum('ativo','inativo','baixado','cancelado','manutencao') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `notas` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  PRIMARY KEY (`drone_id`),
  KEY `fk_drone_model_idx` (`model_id`),
  KEY `fk_drone_tenant_idx` (`tenantID`),
  CONSTRAINT `fk_drone_model` FOREIGN KEY (`model_id`) REFERENCES `drone_model` (`id`),
  CONSTRAINT `fk_drone_tenant` FOREIGN KEY (`tenantID`) REFERENCES `assinante` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drone_model`
--

DROP TABLE IF EXISTS `drone_model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drone_model` (
  `id` int NOT NULL,
  `manufacturer_id` int NOT NULL,
  `model` varchar(45) NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  `spray_system` varchar(20) NOT NULL,
  `nominal_performance` int DEFAULT NULL,
  `nominal_width` int DEFAULT NULL,
  `default_image` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_drone_manuf_idx` (`manufacturer_id`),
  CONSTRAINT `fk_drone_manuf` FOREIGN KEY (`manufacturer_id`) REFERENCES `manufacturer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drone_parts`
--

DROP TABLE IF EXISTS `drone_parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drone_parts` (
  `id` int NOT NULL,
  `manufacturer_id` int DEFAULT NULL,
  `manufacturer_sku` varchar(20) NOT NULL,
  `original_name` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_manuf_id_idx` (`manufacturer_id`),
  CONSTRAINT `fk_manuf_id` FOREIGN KEY (`manufacturer_id`) REFERENCES `manufacturer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ibge_cidades`
--

DROP TABLE IF EXISTS `ibge_cidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ibge_cidades` (
  `codigo` int NOT NULL,
  `nome` varchar(100) NOT NULL,
  `uf_id` int NOT NULL,
  `ddd` int DEFAULT NULL,
  `latitude` decimal(8,6) DEFAULT NULL,
  `longitude` decimal(9,6) DEFAULT NULL,
  PRIMARY KEY (`codigo`),
  KEY `fk_uf_ibge_idx` (`uf_id`),
  CONSTRAINT `fk_uf_ibge` FOREIGN KEY (`uf_id`) REFERENCES `ibge_uf` (`codigo_uf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ibge_uf`
--

DROP TABLE IF EXISTS `ibge_uf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ibge_uf` (
  `codigo_uf` int NOT NULL,
  `sigla` varchar(2) DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `regiao` enum('norte','nordeste','centro-oeste','sudeste','sul') DEFAULT NULL,
  PRIMARY KEY (`codigo_uf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `manufacturer`
--

DROP TABLE IF EXISTS `manufacturer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `manufacturer` (
  `id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `short_name` varchar(45) DEFAULT NULL,
  `default_logo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `misc_content`
--

DROP TABLE IF EXISTS `misc_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `misc_content` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) NOT NULL,
  `sumula` varchar(255) DEFAULT NULL,
  `publico` tinyint NOT NULL DEFAULT '1',
  `url` varchar(255) DEFAULT NULL,
  `conteudo` text,
  `tipo` enum('news','blog','document','announcement') DEFAULT 'news',
  `autor` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_published` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_published` (`is_published`),
  KEY `idx_type` (`tipo`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `model_part`
--

DROP TABLE IF EXISTS `model_part`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_part` (
  `model_id` int NOT NULL,
  `part_id` int NOT NULL,
  PRIMARY KEY (`model_id`,`part_id`),
  KEY `fk_part_id_idx` (`part_id`),
  CONSTRAINT `fk_model_id` FOREIGN KEY (`model_id`) REFERENCES `drone_model` (`id`),
  CONSTRAINT `fk_part_id` FOREIGN KEY (`part_id`) REFERENCES `drone_parts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ordem_servico`
--

DROP TABLE IF EXISTS `ordem_servico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordem_servico` (
  `id` int NOT NULL,
  `tentanID` int DEFAULT NULL,
  `referencia` varchar(10) DEFAULT NULL,
  `produtor_id` int DEFAULT NULL,
  `data_abertura` date DEFAULT NULL,
  `data_inicio` datetime DEFAULT NULL,
  `data_fim` datetime DEFAULT NULL,
  `status` enum('aberta','em execução','finalizada','cancelada') DEFAULT NULL COMMENT '0 - created\\n1 - started\\n2 - in progress\\n3 - interrupted\\n4 - canceled\\n9- finished\\n',
  `informacao_preliminar` varchar(255) DEFAULT NULL,
  `ocorrencias` varchar(255) DEFAULT NULL,
  `notas` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_produtor_idx` (`produtor_id`),
  KEY `fk_os_tenant_idx` (`tentanID`),
  CONSTRAINT `fk_os_tenant` FOREIGN KEY (`tentanID`) REFERENCES `assinante` (`id`),
  CONSTRAINT `fk_produtor_os` FOREIGN KEY (`produtor_id`) REFERENCES `produtor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `orgao`
--

DROP TABLE IF EXISTS `orgao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orgao` (
  `id` int NOT NULL,
  `esfera` enum('federal','estadual','municipal','outras') NOT NULL COMMENT 'Esfera pode ser BR - Federal, UF-Estadual, MU-Municipal , OU-Outras',
  `nome` varchar(255) NOT NULL,
  `sigla` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nome_UNIQUE` (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `os_anexo`
--

DROP TABLE IF EXISTS `os_anexo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `os_anexo` (
  `id` int NOT NULL,
  `id_os` int DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `observacao` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_os_idx` (`id_os`),
  CONSTRAINT `fk_os` FOREIGN KEY (`id_os`) REFERENCES `ordem_servico` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `os_item`
--

DROP TABLE IF EXISTS `os_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `os_item` (
  `id` int NOT NULL,
  `service_order_id` int DEFAULT NULL,
  `data` date DEFAULT NULL,
  `hora` varchar(5) DEFAULT NULL,
  `temperatura` decimal(3,1) DEFAULT NULL,
  `umidade` int DEFAULT NULL,
  `wind_speed` decimal(4,2) DEFAULT NULL,
  `wind_direction` int DEFAULT NULL COMMENT 'wind direction points to WHERE the wind is blowing from (standard convention) for values ranging from:\n\nN: 0 - 25] and ]335-360\nNE: ]25 - 65]\nE: ]65 - 115]\nSE : ]115 - 155]\nS: ]155 - 205]\nSW : ]205 - 245]\nW : ]245 - 295]\nNW : ]295 - 335] \n\n',
  `area_coberta` decimal(5,2) DEFAULT NULL,
  `taxa_aplicacao` int DEFAULT NULL,
  `id_piloto` int DEFAULT NULL,
  `id_drone` int DEFAULT NULL,
  `id_talhao` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_service_order_idx` (`service_order_id`),
  KEY `fk_pilot_idx` (`id_piloto`),
  KEY `fk_drone_idx` (`id_drone`),
  KEY `fk_field_idx` (`id_talhao`),
  CONSTRAINT `fk_drone` FOREIGN KEY (`id_drone`) REFERENCES `drone` (`drone_id`),
  CONSTRAINT `fk_field` FOREIGN KEY (`id_talhao`) REFERENCES `talhao` (`id`),
  CONSTRAINT `fk_pilot` FOREIGN KEY (`id_piloto`) REFERENCES `piloto` (`id`),
  CONSTRAINT `fk_service_order` FOREIGN KEY (`service_order_id`) REFERENCES `ordem_servico` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pilot_credential`
--

DROP TABLE IF EXISTS `pilot_credential`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pilot_credential` (
  `id` int NOT NULL,
  `id_pilot` int DEFAULT NULL,
  `id_orgao` int DEFAULT NULL,
  `credential` varchar(20) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `credential_url` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pilot_id_idx` (`id_pilot`),
  KEY `fk_orgao_id_idx` (`id_orgao`),
  CONSTRAINT `fk_orgao_id` FOREIGN KEY (`id_orgao`) REFERENCES `orgao` (`id`),
  CONSTRAINT `fk_pilot_id` FOREIGN KEY (`id_pilot`) REFERENCES `piloto` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `piloto`
--

DROP TABLE IF EXISTS `piloto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `piloto` (
  `id` int NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `cpf` varchar(20) DEFAULT NULL,
  `fone` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_nome` (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plano`
--

DROP TABLE IF EXISTS `plano`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plano` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `display_name` varchar(50) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `duracao_dias` int DEFAULT NULL,
  `valor_atual` decimal(6,2) NOT NULL,
  `createdAt` bigint NOT NULL,
  `updatedAt` bigint NOT NULL,
  `payment_id` varchar(45) DEFAULT NULL,
  `price_id` varchar(45) DEFAULT NULL,
  `isPaymentActive` tinyint DEFAULT NULL,
  `paymentInterval` enum('day','week','month','year') DEFAULT NULL,
  `paymentInterval_count` int DEFAULT NULL,
  `paymentCurrency` varchar(45) DEFAULT NULL,
  `status` enum('ativo','inativo','cancelado','promo','suspenso') NOT NULL,
  `origem` enum('local','stripe') DEFAULT NULL,
  `obs` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nome_UNIQUE` (`nome`),
  UNIQUE KEY `display_name_UNIQUE` (`display_name`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `produto`
--

DROP TABLE IF EXISTS `produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `observacao` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_produto` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=4784 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `produto_aplicado`
--

DROP TABLE IF EXISTS `produto_aplicado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produto_aplicado` (
  `id` int NOT NULL,
  `id_item_os` int NOT NULL,
  `id_produto` int NOT NULL,
  `dose_aplicada` decimal(7,3) DEFAULT NULL,
  `id_unidade` int DEFAULT NULL COMMENT 'L/ha\\\\nml/ha\\\\nKg/ha\\\\ng/ha\\\\n',
  `nota` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_os_item_idx` (`id_item_os`),
  KEY `fk_unidade_idx` (`id_unidade`),
  KEY `fk_id_prod_idx` (`id_produto`),
  CONSTRAINT `fk_id_prod` FOREIGN KEY (`id_produto`) REFERENCES `produto` (`id`),
  CONSTRAINT `fk_os_item` FOREIGN KEY (`id_item_os`) REFERENCES `os_item` (`id`),
  CONSTRAINT `fk_unidade` FOREIGN KEY (`id_unidade`) REFERENCES `unidade` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `produto_nao_registrado`
--

DROP TABLE IF EXISTS `produto_nao_registrado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produto_nao_registrado` (
  `id_produto` int NOT NULL,
  `id_tipo_produto` int NOT NULL,
  PRIMARY KEY (`id_produto`,`id_tipo_produto`),
  KEY `fk_nao_reg_tipo_idx` (`id_tipo_produto`),
  CONSTRAINT `fk_id_prod_nr` FOREIGN KEY (`id_produto`) REFERENCES `produto` (`id`),
  CONSTRAINT `fk_tipo_prod` FOREIGN KEY (`id_tipo_produto`) REFERENCES `tipo_produto` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `produto_registrado`
--

DROP TABLE IF EXISTS `produto_registrado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produto_registrado` (
  `id_produto` int NOT NULL,
  `id_produto_agrofit` int NOT NULL,
  KEY `fk_prod_agrofit_idx` (`id_produto_agrofit`),
  KEY `fk_prod_reg_idx` (`id_produto`),
  CONSTRAINT `fk_prod_agrofit` FOREIGN KEY (`id_produto_agrofit`) REFERENCES `agrofit_produto` (`numero_registro`),
  CONSTRAINT `fk_prod_reg` FOREIGN KEY (`id_produto`) REFERENCES `produto` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `produtor`
--

DROP TABLE IF EXISTS `produtor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produtor` (
  `id` int NOT NULL,
  `tenantID` int NOT NULL,
  `nome` varchar(255) NOT NULL,
  `apelido` varchar(50) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `fone` varchar(20) NOT NULL,
  `cpf_cnpj` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `id_cidadeIBGE` int DEFAULT NULL,
  `cep` varchar(9) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `endereco` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `numero` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `complemento` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `bairro` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `status` char(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tenant` (`tenantID`),
  KEY `idx_IBGE` (`id_cidadeIBGE`),
  CONSTRAINT `fk_tenant` FOREIGN KEY (`tenantID`) REFERENCES `assinante` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `registro`
--

DROP TABLE IF EXISTS `registro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `registro` (
  `id` int NOT NULL,
  `tenantID` int NOT NULL,
  `id_orgao` int NOT NULL,
  `validade` date DEFAULT NULL,
  `valido` tinyint DEFAULT NULL,
  `document_url` varchar(255) DEFAULT NULL,
  `obs` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_orgao_idx` (`id_orgao`),
  KEY `fk_client_idx` (`tenantID`),
  CONSTRAINT `fk_orgao` FOREIGN KEY (`id_orgao`) REFERENCES `orgao` (`id`),
  CONSTRAINT `fk_tenant_reg` FOREIGN KEY (`tenantID`) REFERENCES `assinante` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `service_category`
--

DROP TABLE IF EXISTS `service_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_category` (
  `id` int NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='AUXILIAR PARA LISTA DE CATEGORIA DE SERVIÇOS DA O.S. \nPARA O TIPO DE SERVIÇO VINCULADO A CADA ITEM DA O.S. SERÁ USADA A TABELA service_type SEGUINDO PADRÃO DO MAPA';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `service_type`
--

DROP TABLE IF EXISTS `service_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_type` (
  `id` int NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `talhao`
--

DROP TABLE IF EXISTS `talhao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `talhao` (
  `id` int NOT NULL,
  `id_area` int DEFAULT NULL,
  `tenantID` int DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `apelido` varchar(50) DEFAULT NULL,
  `latitude` decimal(8,6) DEFAULT NULL,
  `longitude` decimal(9,6) DEFAULT NULL,
  `descricao` varchar(200) DEFAULT NULL,
  `area_total` decimal(6,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_area_idx` (`id_area`),
  KEY `fk_talhao_tenant_idx` (`tenantID`),
  CONSTRAINT `fk_area` FOREIGN KEY (`id_area`) REFERENCES `area` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_talhao_tenant` FOREIGN KEY (`tenantID`) REFERENCES `assinante` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tipo_produto`
--

DROP TABLE IF EXISTS `tipo_produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_produto` (
  `id` int NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `notas` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `unidade`
--

DROP TABLE IF EXISTS `unidade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unidade` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sigla` varchar(10) DEFAULT NULL,
  `descricao` varchar(50) DEFAULT NULL,
  `dose` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sigla_UNIQUE` (`sigla`),
  UNIQUE KEY `descricao_UNIQUE` (`descricao`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-03 18:34:03
