const { updatePlano } = require('./planos');
const { getById, updateById, executeQuery } = require('../../utils/database');
const { getStripeProduct, updateProduct, updatePrice, createPrice, singleShotCreate } = require('../stripe/stripe');

jest.mock('../../utils/database');
jest.mock('../stripe/stripe');

describe('updatePlano', () => {
    afterEach(() => {
        // Restore all mocks after each test to ensure isolation
        jest.restoreAllMocks();
    });

    it('should update a plano and sync with Stripe', async () => {
        const event = {
            routeParams: { id: '1' },
            body: JSON.stringify({
                nome: 'Plano Teste Update',
                valor_atual: 200,
            }),
        };

        const currentPlano = {
            id: '1',
            nome: 'Plano Teste',
            valor_atual: 100,
            payment_id: 'stripe_prod_id',
            price_id: 'stripe_price_id',
            paymentInterval: 'month',
            paymentInterval_count: 1,
            paymentCurrency: 'brl',
            status: 'ativo',
            isPaymentActive: 1,
        };

        const updatedPlanoData = {
            ...currentPlano,
            nome: 'Plano Teste Update',
            valor_atual: 200,
        };

        const currentStripeProduct = {
            id: 'stripe_prod_id',
            name: 'Plano Teste',
            active: true,
            description: 'Descrição do plano',
            metadata: { display_name: 'Plano Teste' },
        };

        getById.mockResolvedValue(currentPlano);
        executeQuery.mockResolvedValue([null]);
        getStripeProduct.mockResolvedValue(currentStripeProduct);
        updateProduct.mockResolvedValue({});
        updatePrice.mockResolvedValue({});
        createPrice.mockResolvedValue({ id: 'new_stripe_price_id' });

        // Mock the sequence of updates
        // 1. The initial update with the new name and valor_atual
        updateById.mockResolvedValueOnce(updatedPlanoData);
        // 2. The update with the new price_id after the old one is changed
        updateById.mockResolvedValueOnce({ ...updatedPlanoData, price_id: 'new_stripe_price_id' });

        const result = await updatePlano(event);

        expect(getById).toHaveBeenCalledWith('plano', '1', '', 'id');
        // Check that the first update was called correctly
        expect(updateById).toHaveBeenNthCalledWith(1, 'plano', '1', { nome: 'Plano Teste Update', valor_atual: 200, updatedAt: expect.any(Number) }, 'id');
        expect(getStripeProduct).toHaveBeenCalledWith('stripe_prod_id');
        expect(updateProduct).toHaveBeenCalledWith('stripe_prod_id', { name: 'Plano Teste Update' });
        expect(updatePrice).toHaveBeenCalledWith('stripe_price_id', { active: false });
        expect(createPrice).toHaveBeenCalled();
        // Check that the second update was called correctly
        expect(updateById).toHaveBeenNthCalledWith(2, 'plano', '1', { price_id: 'new_stripe_price_id', updatedAt: expect.any(Number) }, 'id');
        expect(result.statusCode).toBe(200);
        // Corrected assertion to match the nested response structure
        expect(JSON.parse(result.body).data.message).toBe('Plano Atualizado!');
    });

    it('should recreate stripe product if it is not found on stripe during update', async () => {
        const event = {
            routeParams: { id: '1' },
            body: JSON.stringify({
                nome: 'Plano Teste Update',
                isPaymentActive: 1,
            }),
        };

        const currentPlano = {
            id: '1',
            nome: 'Plano Teste',
            valor_atual: 100,
            isPaymentActive: 1,
            payment_id: 'stripe_prod_id_stale', // An ID that won't be found
            price_id: 'stripe_price_id_stale',
            status: 'ativo',
        };

        const updatedPlanoData = {
            ...currentPlano,
            nome: 'Plano Teste Update',
        };

        const newStripeProduct = {
            id: 'new_stripe_prod_id',
            default_price: 'new_stripe_price_id', // This is the correct Stripe API format
        };

        const finalUpdatedPlano = { ...updatedPlanoData, payment_id: 'new_stripe_prod_id', price_id: 'new_stripe_price_id' };
        getById.mockResolvedValue(currentPlano);
        executeQuery.mockResolvedValue([null]);
        // Mock the first update call in updatePlano
        updateById.mockResolvedValueOnce(updatedPlanoData);
        // Mock Stripe product not being found
        getStripeProduct.mockResolvedValue(null);
        // Mock the recreation call inside the helper
        singleShotCreate.mockResolvedValue({ statusCode: 200, body: JSON.stringify({ data: newStripeProduct }) });
        // Mock the final update call inside the helper
        updateById.mockResolvedValueOnce(finalUpdatedPlano);

        const result = await updatePlano(event);

        expect(getStripeProduct).toHaveBeenCalledWith('stripe_prod_id_stale');
        expect(singleShotCreate).toHaveBeenCalled();
        expect(result.statusCode).toBe(200);
        // Corrected assertions to match the nested response structure
        expect(JSON.parse(result.body).data.message).toBe('Plano Atualizado e integração com Stripe recriada.');
        expect(JSON.parse(result.body).data.data.payment_id).toBe('new_stripe_prod_id');
    });
});