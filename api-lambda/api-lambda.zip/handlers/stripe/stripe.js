const stripe = require('stripe')('sk_test_51SAcRjEoCBqFXsH3jjKWf6WE2lsj71Vq03620LFH5J2B0cOiV43y499VHnd8y0SA0sIBBDUAx1wGf4MjRd7KKH0d00aSmnV8Py')
const { success, serverError } = require('../../utils/response');

async function createProduct(event) {
    try {
        const body = JSON.parse(event.body);
        console.log(body);

        stripe.products.create({
            name: '',
            description: ''
        });
    } catch (error) {
        console.error('CREATE Product Error:', error);
        return serverError('Failed to create product');
    }
}

async function createPrice(event) {
    const body = JSON.parse(event.body);
    const product_id = body.plano_stripeID;

    stripe.prices.create({
        unit_amount: 0,
        currency: 'b',
        recurring: {
            interval: 'month'
        },
        product: product_id
    });
}

async function listStripeProducts(event) {
    const body = JSON.parse(event.body);
    console.log(body)

    const produtos = await stripe.products.list();
    return success({
        data: produtos,
    });
}

async function checkout(event) {
    const body = JSON.parse(event.body);
    const plano_id = body.smartPlano_id;          // nosso ID
    const product_id = body.plano_stripeID;       // ID do produto no Stripe
    const price_id = body.priceId;                // Stripe PriceID
    const sessionMode = body.session_mode;            // payment, setup, subscription
    const paymentType = body.payment_type;


//    const session = await stripe.checkout.sessions.create({
    // try {
    console.log(plano_id, product_id, price_id, sessionMode, paymentType);
    const mock_session = ({
        mode: sessionMode,
        payment_method_types: paymentType,
        line_items: [{price: price_id, quantity: 1}],
        success_url: `${process.env.FRONTEND_URL}/dashboard?session_id={CHECKOU_SESSION_ID}`,
        cancel_url: `${process.env.FRONTEND_URL}/princing`,
    });
    return success({
        data: mock_session,
    });
    //} catch (error) {
    //
    //}
}

module.exports = {
    createProduct,
    createPrice,
    listStripeProducts,
    checkout
}